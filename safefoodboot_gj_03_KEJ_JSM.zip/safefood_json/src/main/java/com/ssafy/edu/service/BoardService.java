package com.ssafy.edu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.edu.dao.BoardMapper;
import com.ssafy.edu.dto.BoardDto;

@Service
public class BoardService {
	@Autowired
    BoardMapper mBoardMapper;
    
    public List<BoardDto> boardListService() throws Exception{
        return mBoardMapper.boardList();
    }
    
    public BoardDto boardDetailService(int bno) throws Exception{
        return mBoardMapper.boardDetail(bno);
    }
    
    public int boardInsertService(BoardDto board) throws Exception{
        return mBoardMapper.boardInsert(board);
    }
    
    public int boardUpdateService(BoardDto board) throws Exception{
        return mBoardMapper.boardUpdate(board);
    }
    
    public int boardDeleteService(int bno) throws Exception{
        return mBoardMapper.boardDelete(bno);
    }
}
