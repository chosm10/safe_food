package com.ssafy.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafefoodJsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(SafefoodJsonApplication.class, args);
	}
}
