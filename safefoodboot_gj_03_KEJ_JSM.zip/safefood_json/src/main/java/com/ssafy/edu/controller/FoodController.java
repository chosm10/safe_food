package com.ssafy.edu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.edu.dto.BoardDto;
import com.ssafy.edu.dto.FoodDto;
import com.ssafy.edu.service.BoardService;
import com.ssafy.edu.service.FoodService;

@CrossOrigin(origins = { "*" })
@RestController
@RequestMapping("/api")
public class FoodController {

	@Autowired
	private FoodService foodService;
	@Autowired
	private BoardService boardservice;

	@RequestMapping(value = {"/selectByName" }, method = RequestMethod.GET)
	public FoodDto selectByName(String name) throws Exception {
		return foodService.selectByName(name);
	}
	
	@RequestMapping(value = {"/", "/selectAll" }, method = RequestMethod.GET)
	public List<FoodDto> selectByName() throws Exception {
		return foodService.selectAll();
	}
	
	@RequestMapping(value = { "/list" }, method = RequestMethod.GET)
	public List<BoardDto> getList() throws Exception {
		return boardservice.boardListService();
	}

//	@RequestMapping(value = "/selectById", method = RequestMethod.POST)
//	public List<QnaDto> selectById(@RequestBody String id) throws Exception {
//		System.out.println("--------------------------");
//		System.out.println(id);
//		return qnaService.selectById(id);
//	}

}
