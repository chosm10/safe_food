package com.ssafy.edu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.edu.dao.FoodMapper;
import com.ssafy.edu.dto.FoodDto;

@Service
public class FoodService {
	@Autowired
	private FoodMapper foodMapper;
	
	public FoodDto selectById(int code) {
		return foodMapper.selectOne(code);
	}
	
	public FoodDto selectByName(String name) {
		return foodMapper.selectByName(name);
	}
	
	public List<FoodDto> selectAll(){
		return foodMapper.selectAll();
	}
}
