package com.ssafy.edu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.edu.dto.BoardDto;
@Mapper
public interface BoardMapper {
	public int boardCount() throws Exception;

	public List<BoardDto> boardList() throws Exception;

	public BoardDto boardDetail(int bno) throws Exception;

	// 게시글 작성
	public int boardInsert(BoardDto board) throws Exception;

	// 게시글 수정
	public int boardUpdate(BoardDto board) throws Exception;

	// 게시글 삭제
	public int boardDelete(int bno) throws Exception;
}
