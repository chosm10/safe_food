package com.ssafy.edu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.edu.dto.FoodDto;
@Mapper
public interface FoodMapper {
	public FoodDto selectOne(int id);
	public FoodDto selectByName(String name);
	public List<FoodDto> selectAll();
}
