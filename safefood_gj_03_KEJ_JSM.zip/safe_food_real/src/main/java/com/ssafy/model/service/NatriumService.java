package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Natrium;
import com.ssafy.model.repository.NatriumRepo;

@Service
public class NatriumService {
	@Autowired
	private NatriumRepo natRepo;

	public List<Natrium> selectAll() {
		return natRepo.selectAll();
	}

	public Natrium selectOne(String nat_id) {
		return natRepo.selectOne(nat_id);
	}

	public int updateNat(Natrium nat) {
		return natRepo.updateNat(nat);
	}

}
