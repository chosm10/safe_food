package com.ssafy.model.repository;

import java.util.List;

import com.ssafy.model.dto.EatenFood;
import com.ssafy.model.dto.Ingestion;

public interface IngestionRepo {
	public int insert(Ingestion igt);

	public int update(Ingestion igt);

	public int delete(int id);

	public Ingestion selectOne(String id);

	public List<Ingestion> selectAll();

	public List<EatenFood> eatenList(String id);

	public List<Integer> findByDate(String id);
}
