package com.ssafy.model.repository;

import java.util.List;

import com.ssafy.model.dto.Food;

public interface FoodRepo {
	public Food selectId(int id);
	public Food selectByName(String name);
	public List<Food> selectAll();
}
