package com.ssafy.model.dto;

public class FoodAllergy {
	private int f_alg_id;
	private int allergy_alg_id;
	private int food_f_code;
	
	public FoodAllergy(int f_alg_id, int allergy_alg_id, int food_f_code) {
		super();
		this.f_alg_id = f_alg_id;
		this.allergy_alg_id = allergy_alg_id;
		this.food_f_code = food_f_code;
	}

	public int getF_alg_id() {
		return f_alg_id;
	}

	public void setF_alg_id(int f_alg_id) {
		this.f_alg_id = f_alg_id;
	}

	public int getAllergy_alg_id() {
		return allergy_alg_id;
	}
	public void setAllergy_alg_id(int allergy_alg_id) {
		this.allergy_alg_id = allergy_alg_id;
	}
	public int getFood_f_code() {
		return food_f_code;
	}
	public void setFood_f_code(int food_f_code) {
		this.food_f_code = food_f_code;
	}

	@Override
	public String toString() {
		return "FoodAllergy [f_alg_id=" + f_alg_id + ", allergy_alg_id=" + allergy_alg_id + ", food_f_code="
				+ food_f_code + "]";
	}
	
}
