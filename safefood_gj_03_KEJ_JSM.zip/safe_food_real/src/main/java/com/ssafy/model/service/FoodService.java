package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Food;
import com.ssafy.model.repository.FoodRepo;

@Service 
public class FoodService {
	
	@Autowired
	private FoodRepo foodRepo;

	
	public Food selectById(int code) {
		return foodRepo.selectId(code);
	}
	
	public Food selectByName(String name) {
		return foodRepo.selectByName(name);
	}
	
	public List<Food> selectAll(){
		return foodRepo.selectAll();
	}
}
