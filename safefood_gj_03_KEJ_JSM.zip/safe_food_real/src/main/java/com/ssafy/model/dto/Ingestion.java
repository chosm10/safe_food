package com.ssafy.model.dto;

/**
 * @author chosm
 *
 */
public class Ingestion {
	private int igt_id;
	private String member_m_id;
	private String igt_date;

	public Ingestion() {
	}

	public Ingestion(int igt_id, String member_m_id, String igt_date) {
		super();
		this.igt_id = igt_id;
		this.member_m_id = member_m_id;
		this.igt_date = igt_date;
	}

	public int getIgt_id() {
		return igt_id;
	}

	public void setIgt_id(int igt_id) {
		this.igt_id = igt_id;
	}

	public String getMember_m_id() {
		return member_m_id;
	}

	public void setMember_m_id(String member_m_id) {
		this.member_m_id = member_m_id;
	}

	public String getIgt_date() {
		return igt_date;
	}

	public void setIgt_date(String igt_date) {
		this.igt_date = igt_date;
	}

	@Override
	public String toString() {
		return "Ingestion [igt_id=" + igt_id + ", member_m_id=" + member_m_id + ", igt_date=" + igt_date + "]";
	}

}
