package com.ssafy.model.repository;

import java.util.List;

import com.ssafy.model.dto.Natrium;

public interface NatriumRepo {
	public List<Natrium> selectAll();
	public Natrium selectOne(String nat_id);
	public int updateNat(Natrium nat);
}
