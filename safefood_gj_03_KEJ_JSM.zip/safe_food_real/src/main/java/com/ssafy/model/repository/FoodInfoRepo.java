package com.ssafy.model.repository;

import java.util.List;

import com.ssafy.model.dto.BestFood;
import com.ssafy.model.dto.FoodInfo;

public interface FoodInfoRepo {
	public int insert(FoodInfo fi);
	public int update(FoodInfo fi);
	public int delete(int id);
	public FoodInfo selectOne(int food_info_id);
	public List<FoodInfo> selectAll();
	public List<BestFood> selectBest();
}
