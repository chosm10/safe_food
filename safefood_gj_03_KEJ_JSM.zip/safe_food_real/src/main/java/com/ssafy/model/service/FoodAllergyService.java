package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.FoodAllergy;
import com.ssafy.model.repository.FoodAllergyRepo;

@Service
public class FoodAllergyService {

	@Autowired
	private FoodAllergyRepo foodAllergyRepo;

	public boolean add(FoodAllergy fa) {
		if (foodAllergyRepo.insert(fa) > 0) {
			return true;
		}
		return false;
	}
	
	public boolean delete(FoodAllergy fa) {
		if(foodAllergyRepo.delete(fa.getF_alg_id())>0) {
			return true;
		}
		return false;
	}
	
	public boolean update(FoodAllergy fa) {
		if(foodAllergyRepo.update(fa)>0) {
			return true;
		}
		return false;
	}
	
	public FoodAllergy selectById(int id) {
		return foodAllergyRepo.selectOne(id);
	}
	
	public List<FoodAllergy> selectAll(){
		return foodAllergyRepo.selectAll();
	}
}
