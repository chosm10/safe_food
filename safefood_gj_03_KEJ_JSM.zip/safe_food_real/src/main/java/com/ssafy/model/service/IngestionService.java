package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.EatenFood;
import com.ssafy.model.dto.Ingestion;
import com.ssafy.model.repository.IngestionRepo;

/**
 * @author chosm
 *
 */
@Service
public class IngestionService {
	@Autowired
	private IngestionRepo repo;

	public void add(Ingestion ingestion) {
		repo.insert(ingestion);
	}

	public void delete(int id) {
		repo.delete(id);
	}

	public boolean update(Ingestion ingestion) {
		if (repo.update(ingestion) < 1) {
			return false;
		}
		return true;
	}

	public Ingestion selectById(String id) {
		return repo.selectOne(id);
	}

	public List<Ingestion> selectAll() {
		return repo.selectAll();
	}

	public List<EatenFood> eatenList(String id) {
		return repo.eatenList(id);
	}

	public List<Integer> findByDate(String id) {
		return repo.findByDate(id);
	}
}
