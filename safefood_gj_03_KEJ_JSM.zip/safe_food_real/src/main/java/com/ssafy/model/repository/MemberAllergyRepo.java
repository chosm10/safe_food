package com.ssafy.model.repository;

import java.util.List;

import com.ssafy.model.dto.MemberAllergy;

public interface MemberAllergyRepo {
	public int insert(MemberAllergy ma);
	public int update(MemberAllergy ma);
	public int delete(String id);
	public MemberAllergy selectOne(int id);
	public List<MemberAllergy> selectAll();
	public List<String> selectById(String id);
}
