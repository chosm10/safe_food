package com.ssafy.model.repository;

import com.ssafy.model.dto.Standard;

public interface StandardRepo {
	public Standard myStandard(Standard s);
}
