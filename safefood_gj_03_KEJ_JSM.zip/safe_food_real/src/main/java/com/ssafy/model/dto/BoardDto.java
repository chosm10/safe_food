package com.ssafy.model.dto;

public class BoardDto {
	private int bno;
	private String subject;
	private String content;
	private String writer;
	private int hit;
	private String reg_date;

	public BoardDto(int bno, String subject, String content, String writer, int hit, String reg_date) {
		super();
		this.bno = bno;
		this.subject = subject;
		this.content = content;
		this.writer = writer;
		this.hit = hit;
		this.reg_date = reg_date;
	}

	public int getHit() {
		return hit;
	}

	public void setHit(int hit) {
		this.hit = hit;
	}

	public BoardDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getBno() {
		return bno;
	}

	public void setBno(int bno) {
		this.bno = bno;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getReg_date() {
		return reg_date;
	}

	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}

	@Override
	public String toString() {
		return "BoardDto [bno=" + bno + ", subject=" + subject + ", content=" + content + ", writer=" + writer
				+ ", hit=" + hit + ", reg_date=" + reg_date + "]";
	}

}
