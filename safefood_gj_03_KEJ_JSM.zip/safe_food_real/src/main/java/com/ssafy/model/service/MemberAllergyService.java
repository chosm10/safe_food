package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.MemberAllergy;
import com.ssafy.model.repository.MemberAllergyRepo;
@Service
public class MemberAllergyService {
	@Autowired
	private MemberAllergyRepo repo;
	
	public void add(MemberAllergy ma) throws Exception {
		repo.insert(ma);
	}

	public boolean delete(String id) {
		if(repo.delete(id) < 1) {
			return false;
		}
		return true;
	}

	public boolean update(MemberAllergy ma) {
		if(repo.update(ma) < 1) {
			return false;
		}
		return true;
	}
	
	public MemberAllergy selectById(int id) {
		return repo.selectOne(id);
	}
	
	public List<String> selectByUserId(String id) {
		return repo.selectById(id);
	}
	
	public List<MemberAllergy> selectAll(){
		return repo.selectAll();
	}
}
