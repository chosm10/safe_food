package com.ssafy.model.repository;

import java.util.List;
import com.ssafy.model.dto.FoodAllergy;

public interface FoodAllergyRepo {
	public int insert(FoodAllergy foodal);
	public int update(FoodAllergy foodal);
	public int delete(int id);
	public FoodAllergy selectOne(int id);
	public List<FoodAllergy> selectAll();
}
