package com.ssafy.model.dto;

public class Standard {
	private int standard_id;
	private int s_gender;
	private int s_age;
	private double s_kcal;
	private int s_protein;
	private double s_natruim;
	private int s_fat;
	private double s_sugar;
	
	public Standard() {};

	public Standard(int standard_id, int s_gender, int s_age, double s_kcal, int s_protein, double s_natruim, int s_fat,
			double s_sugar) {
		super();
		this.standard_id = standard_id;
		this.s_gender = s_gender;
		this.s_age = s_age;
		this.s_kcal = s_kcal;
		this.s_protein = s_protein;
		this.s_natruim = s_natruim;
		this.s_fat = s_fat;
		this.s_sugar = s_sugar;
	}

	public int getStandard_id() {
		return standard_id;
	}

	public void setStandard_id(int standard_id) {
		this.standard_id = standard_id;
	}

	public int getS_gender() {
		return s_gender;
	}

	public void setS_gender(int s_gender) {
		this.s_gender = s_gender;
	}

	public int getS_age() {
		return s_age;
	}

	public void setS_age(int s_age) {
		this.s_age = s_age;
	}

	public double getS_kcal() {
		return s_kcal;
	}

	public void setS_kcal(double s_kcal) {
		this.s_kcal = s_kcal;
	}

	public int getS_protein() {
		return s_protein;
	}

	public void setS_protein(int s_protein) {
		this.s_protein = s_protein;
	}

	public double getS_natruim() {
		return s_natruim;
	}

	public void setS_natruim(double s_natruim) {
		this.s_natruim = s_natruim;
	}

	public int getS_fat() {
		return s_fat;
	}

	public void setS_fat(int s_fat) {
		this.s_fat = s_fat;
	}

	public double getS_sugar() {
		return s_sugar;
	}

	public void setS_sugar(double s_sugar) {
		this.s_sugar = s_sugar;
	}

	@Override
	public String toString() {
		return "Standard [standard_id=" + standard_id + ", s_gender=" + s_gender + ", s_age=" + s_age + ", s_kcal="
				+ s_kcal + ", s_protein=" + s_protein + ", s_natruim=" + s_natruim + ", s_fat=" + s_fat + ", s_sugar="
				+ s_sugar + "]";
	}

}
