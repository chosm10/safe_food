package com.ssafy.model.dto;

public class BestFood implements Comparable<BestFood>{
	private int freq;
	private int f_code;
	public BestFood(int freq, int f_code) {
		super();
		this.freq = freq;
		this.f_code = f_code;
	}
	public int getFreq() {
		return freq;
	}
	public void setFreq(int freq) {
		this.freq = freq;
	}
	public int getF_code() {
		return f_code;
	}
	public void setF_code(int f_code) {
		this.f_code = f_code;
	}
	@Override
	public String toString() {
		return "BestFood [freq=" + freq + ", f_code=" + f_code + "]";
	}
	public int compareTo(BestFood o) {
		if(this.freq > o.freq)
			return -1;
		else if(this.freq < o.freq)
			return 1;
		else {
			return this.f_code - o.f_code;
		}
	}
}
