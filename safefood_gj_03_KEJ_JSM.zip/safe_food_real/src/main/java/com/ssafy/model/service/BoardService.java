package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.BoardDto;
import com.ssafy.model.repository.BoardRepo;

@Service
public class BoardService {
	@Autowired
    private BoardRepo mBoardMapper;
    
    public List<BoardDto> boardListService() throws Exception{
        return mBoardMapper.boardList();
    }
    
    public BoardDto boardDetailService(int bno) throws Exception{
        return mBoardMapper.boardDetail(bno);
    }
    
    public int boardInsertService(BoardDto board) throws Exception{
        return mBoardMapper.boardInsert(board);
    }
    
    public int boardUpdateService(BoardDto board) throws Exception{
        return mBoardMapper.boardUpdate(board);
    }
    
    public int boardDeleteService(int bno) throws Exception{
        return mBoardMapper.boardDelete(bno);
    }
    
    public int boardHitService(BoardDto board) throws Exception {
    	return mBoardMapper.boardHit(board);
    }
}
