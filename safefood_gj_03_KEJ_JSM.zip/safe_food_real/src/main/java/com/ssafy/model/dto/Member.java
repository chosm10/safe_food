package com.ssafy.model.dto;

public class Member {
	
	private String m_id;
	private String m_phone;
	private String m_name;
	private String m_pass;
	private String m_area;
	private int m_gender;
	private int m_weight;
	private int m_height;
	private int m_age;
	
	public Member(String m_id, String m_phone, String m_name, String m_pass, String m_area, int m_gender, int m_weight,
			int m_height, int m_age) {
		super();
		this.m_id = m_id;
		this.m_phone = m_phone;
		this.m_name = m_name;
		this.m_pass = m_pass;
		this.m_area = m_area;
		this.m_gender = m_gender;
		this.m_weight = m_weight;
		this.m_height = m_height;
		this.m_age = m_age;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	public String getM_phone() {
		return m_phone;
	}
	public void setM_phone(String m_phone) {
		this.m_phone = m_phone;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public String getM_pass() {
		return m_pass;
	}
	public void setM_pass(String m_pass) {
		this.m_pass = m_pass;
	}
	public String getM_area() {
		return m_area;
	}
	public void setM_area(String m_area) {
		this.m_area = m_area;
	}
	public int getM_gender() {
		return m_gender;
	}
	public void setM_gender(int m_gender) {
		this.m_gender = m_gender;
	}
	public int getM_weight() {
		return m_weight;
	}
	public void setM_weight(int m_weight) {
		this.m_weight = m_weight;
	}
	public int getM_height() {
		return m_height;
	}
	public void setM_height(int m_height) {
		this.m_height = m_height;
	}
	public int getM_age() {
		return m_age;
	}
	public void setM_age(int m_age) {
		this.m_age = m_age;
	}
	@Override
	public String toString() {
		return "Member [m_id=" + m_id + ", m_phone=" + m_phone + ", m_name=" + m_name + ", m_pass=" + m_pass
				+ ", m_area=" + m_area + ", m_gender=" + m_gender + ", m_weight=" + m_weight + ", m_height=" + m_height
				+ ", m_age=" + m_age + "]";
	}
}
