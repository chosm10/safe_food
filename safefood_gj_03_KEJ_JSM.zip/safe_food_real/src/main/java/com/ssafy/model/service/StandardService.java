package com.ssafy.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Standard;
import com.ssafy.model.repository.StandardRepo;

@Service
public class StandardService {

	@Autowired
	private StandardRepo repo;

	public Standard myStandard(Standard s) {
		return repo.myStandard(s);
	}
}
