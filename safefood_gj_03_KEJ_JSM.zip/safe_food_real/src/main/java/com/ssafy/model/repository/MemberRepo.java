package com.ssafy.model.repository;

import java.util.List;

import com.ssafy.model.dto.Member;

public interface MemberRepo {
	public int insert(Member m);
	public int update(Member m);
	public int delete(String id);
	public Member selectOne(String id);
	public List<Member> selectAll();
}
