package com.ssafy.model.repository;

import java.util.List;

import com.ssafy.model.dto.BoardDto;
public interface BoardRepo {
	public int boardCount() throws Exception;

	public List<BoardDto> boardList() throws Exception;

	public BoardDto boardDetail(int bno) throws Exception;

	// 게시글 작성
	public int boardInsert(BoardDto board) throws Exception;

	// 게시글 수정
	public int boardUpdate(BoardDto board) throws Exception;

	// 게시글 삭제
	public int boardDelete(int bno) throws Exception;
	
	//조회수 증가
	public int boardHit(BoardDto board) throws Exception;
}
