package com.ssafy.model.dto;

public class EatenFood {
	private int food_info_id;
	private int igt_id;
	private String f_img;
	private String f_name;
	private String f_material;
	private String igt_date;
	private String all;

	public EatenFood(int food_info_id, int igt_id, String f_img, String f_name, String f_material, String igt_date) {
		super();
		this.food_info_id = food_info_id;
		this.igt_id = igt_id;
		this.f_img = f_img;
		this.f_name = f_name;
		this.f_material = f_material;
		this.igt_date = igt_date;
	}

	public int getFood_info_id() {
		return food_info_id;
	}

	public void setFood_info_id(int food_info_id) {
		this.food_info_id = food_info_id;
	}

	public int getIgt_id() {
		return igt_id;
	}

	public void setIgt_id(int igt_id) {
		this.igt_id = igt_id;
	}

	public String getF_img() {
		return f_img;
	}

	public void setF_img(String f_img) {
		this.f_img = f_img;
	}

	public String getF_name() {
		return f_name;
	}

	public void setF_name(String f_name) {
		this.f_name = f_name;
	}

	public String getF_material() {
		return f_material;
	}

	public void setF_material(String f_material) {
		this.f_material = f_material;
	}

	public String getIgt_date() {
		return igt_date;
	}

	public void setIgt_date(String igt_date) {
		this.igt_date = igt_date;
	}

	public String getAll() {
		return all;
	}

	public void setAll(String all) {
		this.all = all;
	}

	@Override
	public String toString() {
		return "EatenFood [food_info_id=" + food_info_id + ", igt_id=" + igt_id + ", f_img=" + f_img + ", f_name="
				+ f_name + ", f_material=" + f_material + ", igt_date=" + igt_date + ", all=" + all + "]";
	}

}
