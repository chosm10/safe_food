package com.ssafy.model.dto;

public class FoodInfo {
	private int food_info_id;
	private int ingestion_igt_id;
	private int food_f_code;

	public FoodInfo(int food_info_id, int ingestion_igt_id, int food_f_code) {
		super();
		this.food_info_id = food_info_id;
		this.ingestion_igt_id = ingestion_igt_id;
		this.food_f_code = food_f_code;
	}
	
	public FoodInfo(int ingestion_igt_id, int food_f_code) {
		super();
		this.ingestion_igt_id = ingestion_igt_id;
		this.food_f_code = food_f_code;
	}
	
	public int getFood_info_id() {
		return food_info_id;
	}

	public void setFood_info_id(int food_info_id) {
		this.food_info_id = food_info_id;
	}

	public int getIngestion_igt_id() {
		return ingestion_igt_id;
	}
	public void setIngestion_igt_id(int ingestion_igt_id) {
		this.ingestion_igt_id = ingestion_igt_id;
	}
	public int getFood_f_code() {
		return food_f_code;
	}
	public void setFood_f_code(int food_f_code) {
		this.food_f_code = food_f_code;
	}

	@Override
	public String toString() {
		return "FoodInfo [food_info_id=" + food_info_id + ", ingestion_igt_id=" + ingestion_igt_id + ", food_f_code="
				+ food_f_code + "]";
	}
	
}
