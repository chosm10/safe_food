package com.ssafy.model.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.BestFood;
import com.ssafy.model.dto.FoodInfo;
import com.ssafy.model.repository.FoodInfoRepo;

@Service
public class FoodInfoService {

	@Autowired
	private FoodInfoRepo foodinfoRepo;

	public boolean add(FoodInfo fi) {
		if (foodinfoRepo.insert(fi) > 0) {
			return true;
		}
		return false;
	}

	public boolean delete(FoodInfo fi) {
		if (foodinfoRepo.delete(fi.getFood_info_id()) > 0) {
			return true;
		}
		return false;
	}

	public boolean update(FoodInfo fi) {
		if (foodinfoRepo.update(fi) > 0) {
			return true;
		}
		return false;
	}

	public FoodInfo selectById(int id) {
		return foodinfoRepo.selectOne(id);
	}
	
	public List<FoodInfo> selectAll(){
		return foodinfoRepo.selectAll();
	}
	
	public List<BestFood> selectBest() {
		return foodinfoRepo.selectBest();
	}
}
