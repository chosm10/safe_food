package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Member;
import com.ssafy.model.repository.MemberRepo;
@Service
public class MemberService {
	@Autowired
	private MemberRepo repo;
	
	public void add(Member member) throws Exception{
		repo.insert(member); 
	}

	public boolean delete(Member member) {
		if(repo.delete(member.getM_id()) < 1) {
			return false;
		}
		return true;
	}

	public boolean update(Member member) {
		if(repo.update(member) < 1) {
			return false;
		}
		return true;
	}
	
	public Member selectById(String id) {
		return repo.selectOne(id);
	}
	
	public List<Member> selectAll(){
		return repo.selectAll();
	}
	
	public boolean login(String id, String pass) {
		Member member = selectById(id);
		if(pass.equals(member.getM_pass()))
			return true;
		return false;
	}
}
