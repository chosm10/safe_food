package com.ssafy.model.dto;

public class Food {
	private String f_img;
	private String f_name;
	private String f_material;

	private int f_code;
	private double f_supportpereat;
	private double f_calory;
	private double f_carbo;
	private double f_protein;
	private double f_fat;
	private double f_sugar;
	private double f_natrium;
	private double f_chole;
	private double f_fattyacid;
	private double f_transfat;

	private String f_maker;

	public Food() {
	}

	public Food(String f_img, String f_name, String f_material, int f_code, double f_supportpereat, double f_calory,
			double f_carbo, double f_protein, double f_fat, double f_sugar, double f_natrium, double f_chole,
			double f_fattyacid, double f_transfat, String f_maker) {
		super();
		this.f_img = f_img;
		this.f_name = f_name;
		this.f_material = f_material;
		this.f_code = f_code;
		this.f_supportpereat = f_supportpereat;
		this.f_calory = f_calory;
		this.f_carbo = f_carbo;
		this.f_protein = f_protein;
		this.f_fat = f_fat;
		this.f_sugar = f_sugar;
		this.f_natrium = f_natrium;
		this.f_chole = f_chole;
		this.f_fattyacid = f_fattyacid;
		this.f_transfat = f_transfat;
		this.f_maker = f_maker;
	}

	public String getF_img() {
		return f_img;
	}

	public void setF_img(String f_img) {
		this.f_img = f_img;
	}

	public String getF_name() {
		return f_name;
	}

	public void setF_name(String f_name) {
		this.f_name = f_name;
	}

	public String getF_material() {
		return f_material;
	}

	public void setF_material(String f_material) {
		this.f_material = f_material;
	}

	public int getF_code() {
		return f_code;
	}

	public void setF_code(int f_code) {
		this.f_code = f_code;
	}

	public double getF_supportpereat() {
		return f_supportpereat;
	}

	public void setF_supportpereat(double f_supportpereat) {
		this.f_supportpereat = f_supportpereat;
	}

	public double getF_calory() {
		return f_calory;
	}

	public void setF_calory(double f_calory) {
		this.f_calory = f_calory;
	}

	public double getF_carbo() {
		return f_carbo;
	}

	public void setF_carbo(double f_carbo) {
		this.f_carbo = f_carbo;
	}

	public double getF_protein() {
		return f_protein;
	}

	public void setF_protein(double f_protein) {
		this.f_protein = f_protein;
	}

	public double getF_fat() {
		return f_fat;
	}

	public void setF_fat(double f_fat) {
		this.f_fat = f_fat;
	}

	public double getF_sugar() {
		return f_sugar;
	}

	public void setF_sugar(double f_sugar) {
		this.f_sugar = f_sugar;
	}

	public double getF_natrium() {
		return f_natrium;
	}

	public void setF_natrium(double f_natrium) {
		this.f_natrium = f_natrium;
	}

	public double getF_chole() {
		return f_chole;
	}

	public void setF_chole(double f_chole) {
		this.f_chole = f_chole;
	}

	public double getF_fattyacid() {
		return f_fattyacid;
	}

	public void setF_fattyacid(double f_fattyacid) {
		this.f_fattyacid = f_fattyacid;
	}

	public double getF_transfat() {
		return f_transfat;
	}

	public void setF_transfat(double f_transfat) {
		this.f_transfat = f_transfat;
	}

	public String getF_maker() {
		return f_maker;
	}

	public void setF_maker(String f_maker) {
		this.f_maker = f_maker;
	}

	@Override
	public String toString() {
		return "Food [f_img=" + f_img + ", f_name=" + f_name + ", f_material=" + f_material + ", f_code=" + f_code
				+ ", f_supportpereat=" + f_supportpereat + ", f_calory=" + f_calory + ", f_carbo=" + f_carbo
				+ ", f_protein=" + f_protein + ", f_fat=" + f_fat + ", f_sugar=" + f_sugar + ", f_natrium=" + f_natrium
				+ ", f_chole=" + f_chole + ", f_fattyacid=" + f_fattyacid + ", f_transfat=" + f_transfat + ", f_maker="
				+ f_maker + "]";
	}

}
