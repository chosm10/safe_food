package com.ssafy.model.dto;

public class Natrium {
	private String nat_id;
	private double natrium;
	private String nat_code;
	
	public Natrium() {}

	public Natrium(String nat_id, double natrium, String nat_code) {
		super();
		this.nat_id = nat_id;
		this.natrium = natrium;
		this.nat_code = nat_code;
	}

	public String getNat_id() {
		return nat_id;
	}

	public void setNat_id(String nat_id) {
		this.nat_id = nat_id;
	}

	public double getNatrium() {
		return natrium;
	}

	public void setNatrium(double natrium) {
		this.natrium = natrium;
	}

	public String getNat_code() {
		return nat_code;
	}

	public void setNat_code(String nat_code) {
		this.nat_code = nat_code;
	}

	@Override
	public String toString() {
		return "Natrium [nat_id=" + nat_id + ", natrium=" + natrium + ", nat_code=" + nat_code + "]";
	}

}
