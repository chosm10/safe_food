package com.ssafy.model.dto;

public class MemberAllergy {
	private int m_alg_id;
	private int allergy_alg_id;
	private String member_member_id;
	public MemberAllergy(int m_alg_id, int allergy_alg_id, String member_member_id) {
		super();
		this.m_alg_id = m_alg_id;
		this.allergy_alg_id = allergy_alg_id;
		this.member_member_id = member_member_id;
	}
	public int getM_alg_id() {
		return m_alg_id;
	}
	public void setM_alg_id(int m_alg_id) {
		this.m_alg_id = m_alg_id;
	}
	public int getAllergy_alg_id() {
		return allergy_alg_id;
	}
	public void setAllergy_alg_id(int allergy_alg_id) {
		this.allergy_alg_id = allergy_alg_id;
	}
	public String getMember_member_id() {
		return member_member_id;
	}
	public void setMember_member_id(String member_member_id) {
		this.member_member_id = member_member_id;
	}
	@Override
	public String toString() {
		return "MemberAllergy [m_alg_id=" + m_alg_id + ", allergy_alg_id=" + allergy_alg_id + ", member_member_id="
				+ member_member_id + "]";
	}
}
