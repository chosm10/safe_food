package com.ssafy.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssafy.model.service.MemberService;

@Controller
public class LoginController {

	@Autowired
	private MemberService service;

	@RequestMapping("login.do")
	// 컨트롤러에서 요청 처리를 하기 위해 세션이 필요해? 그렇다면 세션 타입의 참조변수로 입벌리고 있으면 넣어줌
	public String login(HttpSession session, String id, String pass) {

		try {
			boolean chk = service.login(id, pass);
			if (chk) {
				session.setAttribute("id", id);
			}else {
				session.setAttribute("id", "fail");
			}
		} catch (Exception e) {
			// TODO: handle exception
			session.setAttribute("id", "noexist");
		}

		return "redirect:main.do";
	}

	@RequestMapping("logout.do")
	public String logout(HttpSession session) {
		session.removeAttribute("id");
		return "redirect:main.do";
	}
}
