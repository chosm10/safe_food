package com.ssafy.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.model.dto.BestFood;
import com.ssafy.model.dto.BoardDto;
import com.ssafy.model.dto.EatenFood;
import com.ssafy.model.dto.Food;
import com.ssafy.model.dto.FoodInfo;
import com.ssafy.model.dto.Ingestion;
import com.ssafy.model.dto.Member;
import com.ssafy.model.dto.MemberAllergy;
import com.ssafy.model.dto.Natrium;
import com.ssafy.model.dto.Standard;
import com.ssafy.model.service.BoardService;
import com.ssafy.model.service.FoodInfoService;
import com.ssafy.model.service.FoodService;
import com.ssafy.model.service.IngestionService;
import com.ssafy.model.service.MemberAllergyService;
import com.ssafy.model.service.MemberService;
import com.ssafy.model.service.NatriumService;
import com.ssafy.model.service.StandardService;

@Controller
public class MainController {
	@Autowired
	private FoodService service;
	@Autowired
	private MemberService mservice;
	@Autowired
	private IngestionService ingeService;
	@Autowired
	private FoodInfoService fiService;
	@Autowired
	private MemberAllergyService aservice;
	@Autowired
	private StandardService stservice;
	@Autowired
	private NatriumService natService;
	@Autowired
	private BoardService bservice;

	@RequestMapping(value= {"/","main.do"})
	public ModelAndView main() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("food");
		return mav;
	}

	@RequestMapping("registform.do")
	public ModelAndView registform() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("signupform");
		return mav;
	}

	@RequestMapping("editinfo.do")
	public ModelAndView editinfo(String id) {
		ModelAndView mav = new ModelAndView();
		Member member = mservice.selectById(id);
		List<String> allergys = aservice.selectByUserId(id);
		String result = null;
		StringBuilder sb = new StringBuilder();
		for (String s : allergys) {
			sb.append(s).append(" ");
		}
		result = sb.toString();
		mav.addObject("member", member);
		mav.addObject("allergys", result);
		mav.setViewName("editinfo");
		return mav;
	}

	@RequestMapping(value = "foodview.do", method = RequestMethod.GET)
	public ModelAndView foodview(String name) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("food", service.selectByName(name));
		mav.setViewName("foodview");
		return mav;
	}

	@RequestMapping(value = "delete.do", method = RequestMethod.GET)
	public String delete(HttpSession session, String id) {
		mservice.delete(mservice.selectById(id));
		session.removeAttribute("id");
		return "redirect:main.do";
	}

	@RequestMapping(value = "memberEdit.do", method = RequestMethod.POST)
	public String memberEdit(String id, String pass, String name, String phone, int age, double height, double weight,
			String region, int gender, String[] al) {

		System.out.println(id + " " + pass + " " + weight + " " + name);
		Member member = new Member(id, phone, name, pass, region, gender, (int) weight, (int) height, age);
		mservice.update(member);
		aservice.delete(id);
		try {
			for (int i = 0; i < al.length; i++) {
				aservice.add(new MemberAllergy(0, Integer.parseInt(al[i]), id));
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "redirect:main.do";
	}

	@RequestMapping(value = "eaten.do", method = RequestMethod.GET)
	public ModelAndView eaten(HttpSession session, int foodcode) {
		ModelAndView mav = new ModelAndView();
		Date d = new Date();
		SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Ingestion inge = new Ingestion();
			inge.setMember_m_id((String) session.getAttribute("id"));
			inge.setIgt_date(date.format(d));
			ingeService.add(inge);

			FoodInfo fi = new FoodInfo(inge.getIgt_id(), foodcode);
			fiService.add(fi);

			Natrium nat = new Natrium();
			Member m = mservice.selectById((String) session.getAttribute("id"));
			nat = natService.selectOne(m.getM_area());
			nat.setNatrium(nat.getNatrium() + service.selectById(foodcode).getF_natrium() / 1000);
			natService.updateNat(nat);

			mav.addObject("ok", true);
		} catch (Exception e) {
			mav.addObject("ok", false);
		}
		mav.setViewName("food");
		return mav;
	}

	@RequestMapping(value = "eatenList.do", method = RequestMethod.GET)
	public ModelAndView eatenList(HttpSession session) {
		ModelAndView mav = new ModelAndView();
		List<EatenFood> list = ingeService.eatenList((String) session.getAttribute("id")); // 이 회원이 먹은 음식
		List<String> myAllergy = aservice.selectByUserId((String) session.getAttribute("id")); // 이 회원의 알레르기

		// 알레르기정보 : a이면 알레르기
		if (myAllergy.size() != 0) {
			for (int i = 0; i < list.size(); i++) {
				for (int j = 0; j < myAllergy.size(); j++) {
					if (list.get(i).getF_material().contains(myAllergy.get(j))) {
						list.get(i).setAll("a");
						break;
					} else {
						list.get(i).setAll("b");
					}
				}
			}
		}

		mav.addObject("list", list);
		mav.setViewName("eatenList");
		return mav;
	}

	@RequestMapping(value = "eatendelete.do", method = RequestMethod.GET)
	public String eatenDelete(HttpSession session, int id, String fi) { // id: 섭취 아이디

		// 섭취 삭제되면 나트륨도 감소
		FoodInfo info = fiService.selectById(Integer.parseInt(fi));
		Food food = service.selectById(info.getFood_f_code());
		double nat = food.getF_natrium() / 1000;
		Member m = mservice.selectById((String) session.getAttribute("id"));
		String area = m.getM_area();

		Natrium natrium = natService.selectOne(area);
		natrium.setNatrium(natrium.getNatrium() - nat);
		natService.updateNat(natrium);
		ingeService.delete(id);

		return "redirect:eatenList.do";
	}

	@RequestMapping(value = "bestList.do", method = RequestMethod.GET)
	public ModelAndView besttList() {
		ModelAndView mav = new ModelAndView();
		List<BestFood> list = fiService.selectBest();
		Collections.sort(list);
		Food[] foods = new Food[3];
		for(int i = 0; i < 3; i++) {
			foods[i] = null;
		}
		for(int i = 0; i < list.size() && i < 3; i++) {
			foods[i] = service.selectById(list.get(i).getF_code());
		}
		mav.addObject("food1", foods[0]);
		mav.addObject("food2", foods[1]);
		mav.addObject("food3", foods[2]);
		mav.addObject("list", list);
		mav.setViewName("bestList");
		return mav;
	}

	@RequestMapping(value = "regist.do", method = RequestMethod.POST)
	public ModelAndView regist(String id, String pass, String userName, String phone, int age, double height,
			double weight, String region, int gender, String[] al) {
		ModelAndView mav = new ModelAndView();
		Member member = new Member(id, phone, userName, pass, region, gender, (int) weight, (int) height, age);
		try {
			mservice.add(member);
			mav.addObject("ok", true);
			mav.setViewName("food");
			for (int i = 0; i < al.length; i++) {
				aservice.add(new MemberAllergy(0, Integer.parseInt(al[i]), id));
			}
		} catch (Exception e) {
			// TODO: handle exception
			mav.addObject("ok", false);
			mav.setViewName("signupform");
		}
		return mav;
	}

	@RequestMapping(value = "analysis.do", method = RequestMethod.GET)
	public ModelAndView analysis(HttpSession session) {
		// 보낼때 지역코드, 지역명, 지역염분량 을 데이터로 보냄.

		ModelAndView mav = new ModelAndView();
		List<Food> myfoods = new ArrayList();
		Food food = new Food();

		try {
			List<Integer> list = ingeService.findByDate((String) session.getAttribute("id")); // list : 현재 아이디 사용자가 섭취한

			for (int i = 0; i < list.size(); i++) {
				myfoods.add(service.selectById(list.get(i)));
			}

			for (int i = 0; i < myfoods.size(); i++) {
				food.setF_calory(food.getF_calory() + myfoods.get(i).getF_calory());
				food.setF_carbo(food.getF_carbo() + myfoods.get(i).getF_carbo());
				food.setF_protein(food.getF_protein() + myfoods.get(i).getF_protein());
				food.setF_fat(food.getF_fat() + myfoods.get(i).getF_fat());
				food.setF_sugar(food.getF_sugar() + myfoods.get(i).getF_sugar());
				food.setF_natrium(food.getF_natrium() + myfoods.get(i).getF_natrium());
			}

			food.setF_calory(Math.round((food.getF_calory() / 30) * 100) / 100.0);
			food.setF_carbo(Math.round((food.getF_carbo() / 30) * 100) / 100.0);
			food.setF_protein(Math.round((food.getF_protein() / 30) * 100) / 100.0);
			food.setF_fat(Math.round((food.getF_fat() / 30) * 100) / 100.0);
			food.setF_sugar(Math.round((food.getF_sugar() / 30) * 100) / 100.0);
			food.setF_natrium(Math.round((food.getF_natrium() / 30 / 1000) * 100) / 100.0);
			mav.addObject("food", food);

			Standard s = cal((String) session.getAttribute("id"));
			mav.addObject("standard", s);
			mav.addObject("member", mservice.selectById((String) session.getAttribute("id")));

			List<Natrium> natrium = natService.selectAll();
			Collections.sort(natrium, new Comparator<Natrium>() {

				public int compare(Natrium o1, Natrium o2) {
					if (o1.getNatrium() > o2.getNatrium())
						return -1;
					else if (o1.getNatrium() < o2.getNatrium())
						return 1;
					else
						return 0;
				}
			});
			// natrium : 지역명, 나트륨량, 지역코드
			for (int i = 0; i < natrium.size(); i++) {
				natrium.get(i).setNatrium(Math.round((natrium.get(i).getNatrium()) * 100 / 30) / 100.0);
			}
			mav.addObject("natrium", natrium);

			// code : 지역코드만
			List<String> code = new ArrayList<String>();
			for (int i = 0; i < natrium.size(); i++) {
				if (natrium.get(i).getNatrium() != 0)
					code.add(natrium.get(i).getNat_code());
			}
			mav.addObject("code", code);

			mav.setViewName("analysis");
		} catch (Exception e) {
			mav.setViewName("food");
		}

		return mav;
	}
	
	@RequestMapping(value = "boardinsert.do", method = RequestMethod.GET)
	public ModelAndView boardinsert() {
		ModelAndView mav = new ModelAndView();

		mav.setViewName("boardinsert");
		return mav;
	}
	
	@RequestMapping(value = "boardinsertProc.do", method = RequestMethod.POST)
	public String boardinsert(HttpServletRequest request) throws Exception {
		BoardDto board = new BoardDto();
		board.setSubject(request.getParameter("subject"));
		board.setContent(request.getParameter("content"));
		board.setWriter(request.getParameter("writer"));
		bservice.boardInsertService(board);
		return "redirect:main.do";
	}
	
	@RequestMapping(value = "boardlist.do", method = RequestMethod.GET)
	public ModelAndView boardlist(String id) throws Exception {
		//id는 내글만 보기 때 사용
		ModelAndView mav = new ModelAndView();
		List<BoardDto> list = bservice.boardListService();
		mav.addObject("list", list);
		mav.addObject("id", id);//본인이 게시한 글이면 삭제해야 하므로 id검증에 필요
		mav.setViewName("boardlist");
		return mav;
	}
	
	@RequestMapping(value = "boarddetail.do", method = RequestMethod.GET)
	public ModelAndView boarddetail(String id, int bno) throws Exception {
		//id는 내글만 보기 때 사용
		ModelAndView mav = new ModelAndView();
		BoardDto board = bservice.boardDetailService(bno);
		bservice.boardHitService(board);
		mav.addObject("auth", id.equals(board.getWriter()));
		mav.addObject("board", board);
		mav.setViewName("boarddetail");
		return mav;
	}
	
	@RequestMapping(value = "boardupdate.do", method = RequestMethod.GET)
	public ModelAndView boardupdate(int bno) throws Exception {
		//id는 내글만 보기 때 사용
		ModelAndView mav = new ModelAndView();
		BoardDto board = bservice.boardDetailService(bno);
		mav.addObject("board", board);
		mav.setViewName("boardupdate");
		return mav;
	}
	
	@RequestMapping(value = "boardupdateProc.do", method = RequestMethod.POST)
	public String boardupdateProc(HttpServletRequest request) throws Exception {
		BoardDto board = new BoardDto();
		board.setBno(Integer.parseInt(request.getParameter("bno")));
		board.setSubject(request.getParameter("subject"));
		board.setContent(request.getParameter("content"));
		bservice.boardUpdateService(board);
		return "redirect:main.do";
	}
	
	@RequestMapping(value = "boarddelete.do", method = RequestMethod.GET)
	public String boarddelete(int bno) throws Exception {
		bservice.boardDeleteService(bno);
		return "redirect:main.do";
	}

	public Standard cal(String id) {
		Member m = mservice.selectById(id);
		int age = m.getM_age();
		int gender = m.getM_gender();
		Standard s = new Standard();
		s.setS_age(age);
		s.setS_gender(gender);
		s = stservice.myStandard(s);

		return s;
	}

}
