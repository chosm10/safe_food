package com.ssafy.vo;

public class MemberVO {
	private String mId;
	private String mName;
	private String mPass;
	private String mAddr;
	private String mPhone;

	public MemberVO() {
	}

	public MemberVO(String mId, String mPass, String mName, String mAddr, String mPhone) {
		this.mId = mId;
		this.mName = mName;
		this.mPass = mPass;
		this.mAddr = mAddr;
		this.mPhone = mPhone;
	}

	public String getmId() {
		return mId;
	}

	public void setmId(String mId) {
		this.mId = mId;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public String getmPass() {
		return mPass;
	}

	public void setmPass(String mPass) {
		this.mPass = mPass;
	}

	public String getmAddr() {
		return mAddr;
	}

	public void setmAddr(String mAddr) {
		this.mAddr = mAddr;
	}

	public String getmPhone() {
		return mPhone;
	}

	public void setmPhone(String mPhone) {
		this.mPhone = mPhone;
	}

}
