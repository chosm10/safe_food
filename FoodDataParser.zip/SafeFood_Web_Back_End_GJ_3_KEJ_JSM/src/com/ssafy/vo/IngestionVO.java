package com.ssafy.vo;

public class IngestionVO {
	private int ingeId;
	private String mid;

	public IngestionVO() {
	}

	public IngestionVO(int ingeId, String mid) {
		super();
		this.ingeId = ingeId;
		this.mid = mid;
	}

	public int getIngeId() {
		return ingeId;
	}

	public void setIngeId(int ingeId) {
		this.ingeId = ingeId;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	@Override
	public String toString() {
		return "IngestionVO [ingeId=" + ingeId + ", mid=" + mid + "]";
	}

}
