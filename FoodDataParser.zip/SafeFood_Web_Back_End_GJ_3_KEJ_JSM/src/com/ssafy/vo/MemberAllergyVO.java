package com.ssafy.vo;

public class MemberAllergyVO {
	private String mId;
	private int mAlgId;
	public MemberAllergyVO() {}
	
	public MemberAllergyVO(String mId, int mAlgId) {
		this.mId = mId;
		this.mAlgId = mAlgId;
	}

	public String getmId() {
		return mId;
	}

	public void setmId(String mId) {
		this.mId = mId;
	}

	public int getmAlgId() {
		return mAlgId;
	}

	public void setmAlgId(int mAlgId) {
		this.mAlgId = mAlgId;
	}

	@Override
	public String toString() {
		return "MemberVO [mId=" + mId + ", mAlgId=" + mAlgId + "]";
	}

}
