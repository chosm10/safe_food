package com.ssafy.vo;

public class FoodinfoVO {
	private int f_id;
	private int igt_id;

	public FoodinfoVO() {
	}

	public FoodinfoVO(int f_id, int igt_id) {
		super();
		this.f_id = f_id;
		this.igt_id = igt_id;
	}

	public int getF_id() {
		return f_id;
	}

	public void setF_id(int f_id) {
		this.f_id = f_id;
	}

	public int getIgt_id() {
		return igt_id;
	}

	public void setIgt_id(int igt_id) {
		this.igt_id = igt_id;
	}

	@Override
	public String toString() {
		return "foodinfoVO [f_id=" + f_id + ", igt_id=" + igt_id + "]";
	}

}
