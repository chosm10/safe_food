package com.ssafy.vo;

public class FoodAllergyVO {
	private int allergyAlgId;
	private int foodFCode;
	public FoodAllergyVO() {}
	public int getAllergyAlgId() {
		return allergyAlgId;
	}
	public void setAllergyAlgId(int allergyAlgId) {
		this.allergyAlgId = allergyAlgId;
	}
	public int getFoodFCode() {
		return foodFCode;
	}
	public void setFoodFCode(int foodFCode) {
		this.foodFCode = foodFCode;
	}
	public FoodAllergyVO(int allergyAlgId, int foodFCode) {
		super();
		this.allergyAlgId = allergyAlgId;
		this.foodFCode = foodFCode;
	}
	@Override
	public String toString() {
		return "FoodAllergyVO [allergyAlgId=" + allergyAlgId + ", foodFCode=" + foodFCode + "]";
	}
	
	
}
