package com.ssafy.service;

import com.ssafy.dao.MemberDao;
import com.ssafy.vo.MemberVO;

public class LoginService {
	private static LoginService service = new LoginService();
	MemberDao md = MemberDao.getInstance();
	public static LoginService getService() {
		return service;
	}

	private LoginService() {
	}

	public boolean login(String id, String pass) {
		MemberVO member =md.selectOne(id);
		if(member==null) {
			return false;
		}else {
			if(md.selectOne(id).getmPass().equals(pass)) {
				return true;
			}else {
				return false;
			}
		}
	}
}
