package com.ssafy.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.dao.FoodDao;
import com.ssafy.dao.FoodinfoDao;
import com.ssafy.dao.IngestionDao;
import com.ssafy.vo.FoodVO;
import com.ssafy.vo.FoodinfoVO;

/**
 * Servlet implementation class EatenServlet
 */
@WebServlet("/eaten")
public class EatenServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IngestionDao igd = IngestionDao.getInstance();
	FoodinfoDao fid = FoodinfoDao.getInstance();
	FoodDao fd = FoodDao.getInstance();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String name = request.getParameter("foodname");

		List<FoodVO> list = fd.select();
		int code = -1;
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getName().equals(name)) {
				code = list.get(i).getCode();
				break;
			}
		}

		HttpSession session = request.getSession();
		// Member member = mgr.searchById((String) session.getAttribute("loginId"));
		// member.getEaten().add(new FoodVO(img, name, material));
		String mId = (String) session.getAttribute("loginId"); // 회원의 아이디
		igd.insert(mId , code);
		

		RequestDispatcher disp = request.getRequestDispatcher("addresult.jsp");
		disp.forward(request, response);
	}

}
