package com.ssafy.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.dao.MemberDao;
import com.ssafy.vo.MemberVO;

/**
 * Servlet implementation class MemberServlet
 */
@WebServlet("/member")
public class MemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemberServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String id = request.getParameter("id");
		String name = request.getParameter("userName");
		String pass = request.getParameter("pass");
		String addr = request.getParameter("addr");
		String phone = request.getParameter("phone");
		
		MemberDao dao = MemberDao.getInstance();
		dao.insertMember(new MemberVO(id, pass, name, addr, phone));
		
		String[] al = request.getParameterValues("al");
		
		RequestDispatcher disp = request.getRequestDispatcher("JoinResult.html");
		disp.forward(request, response);
	}

}