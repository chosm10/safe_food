package com.ssafy.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.dao.MemberAllergyDao;
import com.ssafy.dao.MemberDao;
import com.ssafy.vo.MemberAllergyVO;

/**
 * Servlet implementation class MemberServlet
 */
@WebServlet("/memberEdit")
public class MemberEditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	MemberDao md = MemberDao.getInstance();
	MemberAllergyDao mad = MemberAllergyDao.getInstance();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MemberEditServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");

		String[] al = null;
		List<MemberAllergyVO> list = mad.selectAll();
		if (request.getParameterValues("al") != null) {
			al = request.getParameterValues("al");
		}

		// al에 있는정보를 추가하고 없는건 삭제
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("loginId");
		mad.deleteMemberAllergy(id);

		if (al.length != 0) {
			for (int i = 0; i < al.length; i++) {
				MemberAllergyVO mav = new MemberAllergyVO(id, mad.getAlleCode(al[i]));
			}
		}

		RequestDispatcher disp = request.getRequestDispatcher("food.jsp");
		disp.forward(request, response);
	}

}
