package com.ssafy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.vo.FoodinfoVO;

public class FoodinfoDao {

	private Connection conn;
	private static FoodinfoDao instance;

	private FoodinfoDao() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1/safe_food?characterEncoding=UTF-8&serverTimezone=UTC", "root", "1234");
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static FoodinfoDao getInstance() {
		if (instance == null)
			instance = new FoodinfoDao();
		return instance;
	}

	public void insert(FoodinfoVO f) {
		String sql = "INSERT INTO food_info(food_f_code, ingestion_igt_id) VALUES(?,?)";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, f.getF_id());
			pstmt.setInt(2, f.getIgt_id());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public List<FoodinfoVO> select() {
		String sql = "SELECT * FROM food_info";

		List<FoodinfoVO> infos = new ArrayList<>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				FoodinfoVO f = new FoodinfoVO();
				f.setF_id(rs.getInt(1));
				f.setIgt_id(rs.getInt(2));
				infos.add(f);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return infos;
	}

	public int selectOne(int code) { //code : 섭취코드
		String sql = "SELECT food_f_code FROM food_info WHERE ingestion_igt_id=?";

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int foodCode = -1;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, code);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				foodCode = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return foodCode;
	}

	public void delete(int code) {
		String sql = "DELETE FROM food_info WHERE food_f_code=?;";

		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, code);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
