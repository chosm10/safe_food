package com.ssafy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.vo.MemberAllergyVO;

public class MemberAllergyDao {
	private static MemberAllergyDao instance = null;
	private Connection conn;

	private MemberAllergyDao() {
		// 커넥션 연결
		// 1. Driver 적재
		// 2. Connection 획득
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1/safe_food?characterEncoding=UTF-8&serverTimezone=UTC", "root", "1234");
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static MemberAllergyDao getInstance() {
		if (instance == null)
			instance = new MemberAllergyDao();
		return instance;
	}

	public int insertMemberAllergy(MemberAllergyVO memberAlg) {
		String sql = "INSERT INTO member_allergy(allergy_alg_id, member_member_id) VALUES(?,?)";
		PreparedStatement pstmt = null;
		int result = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, memberAlg.getmAlgId());
			pstmt.setString(2, memberAlg.getmId());
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}

	public int deleteMemberAllergy(String mId) {
		String sql = "DELETE FROM member_allergy WHERE member_member_id = ?";
		PreparedStatement pstmt = null;
		int result = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mId);
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}

	public List<MemberAllergyVO> selectOne(String mId) {
		String sql = "SELECT * FROM member_allergy WHERE member_member_id = ?";
		PreparedStatement pstmt = null;
		List<MemberAllergyVO> memberAlg = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			memberAlg = new ArrayList<>();
			pstmt.setString(1, mId);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				MemberAllergyVO mag = new MemberAllergyVO();
				mag.setmAlgId(rs.getInt(1));
				mag.setmId(rs.getString(2));
				memberAlg.add(mag);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return memberAlg;
	}
	
	//알레르기의 이름
	public String AllName(int code) { //code : 알레르기코드
		String sql = "SELECT alg_name FROM allergy WHERE alg_id=?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String name=null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, code);
			rs = pstmt.executeQuery();
			
			name = rs.getString(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
	}

	public List<MemberAllergyVO> selectAll() {
		String sql = "SELECT * FROM member_allergy";
		PreparedStatement pstmt = null;
		MemberAllergyVO memberAlg = null;
		ResultSet rs = null;
		List<MemberAllergyVO> memberAlgList = new ArrayList<>();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				memberAlg = new MemberAllergyVO();
				memberAlg.setmAlgId(rs.getInt("allergy_alg_id"));
				memberAlg.setmId(rs.getString("member_member_id"));
				memberAlgList.add(memberAlg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return memberAlgList;
	}

	// 알레르기 코드를 가져오는 함수하나 만들자
	public int getAlleCode(String name) {
		String sql = "SELECT alg_id FROM allergy WHERE alg_name=?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int code = -1;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			
			code = rs.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return code;
	}
}
