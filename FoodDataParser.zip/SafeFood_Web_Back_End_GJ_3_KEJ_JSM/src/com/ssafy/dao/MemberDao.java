package com.ssafy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.vo.MemberVO;


public class MemberDao {
	private static MemberDao instance = null;
	private Connection conn;

	private MemberDao() {
		// 커넥션 연결
		// 1. Driver 적재
		// 2. Connection 획득
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/safe_food?characterEncoding=UTF-8&serverTimezone=UTC","root","1234");
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static MemberDao getInstance() {
		if (instance == null)
			instance = new MemberDao();
		return instance;
	}

	public int insertMember(MemberVO member) {
		String sql = "INSERT INTO member VALUES(?,?,?,?,?)";
		PreparedStatement pstmt = null;
		int result = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getmId());
			pstmt.setString(2, member.getmPass());
			pstmt.setString(3, member.getmName());
			pstmt.setString(4, member.getmAddr());
			pstmt.setString(5, member.getmPhone());
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public int updateMember(MemberVO member) {
		String sql = 
		"UPDATE member SET m_pass = ?, m_name = ?, m_addr = ?, m_phone = ? WHERE m_id = ?";
		PreparedStatement pstmt = null;
		int result = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(5, member.getmId());
			pstmt.setString(1, member.getmPass());
			pstmt.setString(2, member.getmName());
			pstmt.setString(3, member.getmAddr());
			pstmt.setString(4, member.getmPhone());
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public int deleteMember(String mId) {
		String sql = "DELETE FROM member WHERE m_id = ?";
		PreparedStatement pstmt = null;
		int result = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mId);
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public MemberVO selectOne(String mId) {
		String sql = "SELECT * FROM member WHERE m_id = ?";
		PreparedStatement pstmt = null;
		MemberVO member = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mId);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				member = new MemberVO();
				member.setmId(rs.getString(1));
				member.setmPass(rs.getString(2));
				member.setmName(rs.getString(3));
				member.setmAddr(rs.getString(4));
				member.setmPhone(rs.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if(rs != null)
					rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return member;
	}
	
	public List<MemberVO> selectAll() {
		String sql = "SELECT * FROM member";
		PreparedStatement pstmt = null;
		MemberVO member = null;
		ResultSet rs = null;
		List<MemberVO> memberList = new ArrayList<>();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				member = new MemberVO();
				member.setmId(rs.getString("m_id"));
				member.setmPass(rs.getString("m_pass"));
				member.setmName(rs.getString("m_name"));
				member.setmAddr(rs.getString("m_addr"));
				member.setmPhone(rs.getString("m_phone"));
				memberList.add(member);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if(rs != null)
					rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return memberList;
	}
}
