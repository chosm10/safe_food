package com.ssafy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.vo.IngestionVO;

public class IngestionDao {

	private Connection conn;
	private static IngestionDao instance;

	private IngestionDao() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1/safe_food?characterEncoding=UTF-8&serverTimezone=UTC", "root", "1234");
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static IngestionDao getInstance() {
		if (instance == null)
			instance = new IngestionDao();
		return instance;
	}

	public int getCount() {
		String sql = "SELECT COUNT(*) FROM ingestion";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = -1;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	public void insert(String mId, int code) { // mId : 회원코드, code: 푸드코드, id: 섭취코드
		String sql = "INSERT INTO Ingestion VALUES(?,?);";
		PreparedStatement pstmt = null;
		int id = getCount();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id + 1);
			pstmt.setString(2, mId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// 푸드아이디, 섭취아이디 --> food_info에 추가
		sql = "INSERT INTO food_info(food_f_code, ingestion_igt_id) VALUES(?,?)";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, code);
			pstmt.setInt(2, id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<IngestionVO> select() {
		String sql = "SELECT * FROM ingestion";

		List<IngestionVO> inge = new ArrayList<>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				IngestionVO igt = new IngestionVO();
				igt.setMid(rs.getString(1));
				inge.add(igt);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return inge;
	}

	public List<IngestionVO> selectOne(String code) { // 멤버의 아이디로 검색해야함-> 이 아이디에 해당하는 섭취가 여러개
		String sql = "SELECT * FROM ingestion WHERE member_m_id=?";

		List<IngestionVO> list = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, code);
			rs = pstmt.executeQuery();
			list = new ArrayList<>();
			while (rs.next()) {
				IngestionVO itv = new IngestionVO();
				itv.setIngeId(rs.getInt(1));
				itv.setMid(rs.getString(2));
				list.add(itv);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	public void delete(String code) { // 멤버의 아이디로 삭제해야함(조금애매..)
		String sql = "DELETE FROM ingestion WHERE member_m_id=?";

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, code);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
