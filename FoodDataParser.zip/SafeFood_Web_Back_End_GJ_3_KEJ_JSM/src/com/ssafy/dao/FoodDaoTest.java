package com.ssafy.dao;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.core.IsNull;
import org.junit.BeforeClass;
import org.junit.Test;

import SAXparser.FoodSaxParser;

public class FoodDaoTest {
	private static FoodDao dao;
	private static FoodSaxParser fsp;

	@BeforeClass
	public static void before() {
		dao = FoodDao.getInstance();
	}

	@Test
	public void insert() {
		fsp = new FoodSaxParser();
		System.out.println(fsp.getFoods().size());
		for (int i = 0; i < fsp.getFoods().size(); i++) {

			dao.insert(fsp.getFoods().get(i));
			System.out.println(fsp.getFoods().get(i).toString());
		}
	}

//	@Test
//	public void selectOne() {
//		Food food = dao.selectOne(1);
//		List<Food> list = new ArrayList<>();
//		list.add(food);
//		assertThat(list.size(), is(1));
//		
//		System.out.println(food.toString());
//	}
//
//	@Test
//	public void select() {
//		List<Food> list = dao.select();
//		assertThat(list, is(IsNull.notNullValue()));
//	}

}
