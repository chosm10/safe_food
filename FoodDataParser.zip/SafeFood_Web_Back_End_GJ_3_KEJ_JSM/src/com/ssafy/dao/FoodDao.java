package com.ssafy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.vo.FoodVO;

public class FoodDao {

	private Connection conn;
	private static FoodDao instance;

	private FoodDao() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1/safe_food?characterEncoding=UTF-8&serverTimezone=UTC", "root", "1234");
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static FoodDao getInstance() {
		if (instance == null)
			instance = new FoodDao();
		return instance;
	}

	public int insert(FoodVO f) {
		String sql = "INSERT INTO food VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, f.getImg());
			pstmt.setString(2, f.getName());
			pstmt.setString(3, f.getMaterial());
			pstmt.setInt(4, f.getCode());
			pstmt.setDouble(5, f.getSupportpereat());
			pstmt.setDouble(6, f.getCalory());
			pstmt.setDouble(7, f.getCarbo());
			pstmt.setDouble(8, f.getProtein());
			pstmt.setDouble(9, f.getFat());
			pstmt.setDouble(10, f.getSugar());
			pstmt.setDouble(11, f.getNatrium());
			pstmt.setDouble(12, f.getChole());
			pstmt.setDouble(13, f.getFattyacid());
			pstmt.setDouble(14, f.getTransfat());
			pstmt.setString(15, f.getMaker());
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return -1;
	}

	public List<FoodVO> select() {
		String sql = "SELECT * FROM food";

		List<FoodVO> foods = new ArrayList<>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				FoodVO f = new FoodVO();
				f.setImg(rs.getString(1));
				f.setName(rs.getString(2));
				f.setMaterial(rs.getString(3));
				f.setCode(rs.getInt(4));
				f.setSupportpereat(rs.getDouble(5));
				f.setCalory(rs.getDouble(6));
				f.setCarbo(rs.getDouble(7));
				f.setProtein(rs.getDouble(8));
				f.setFat(rs.getDouble(9));
				f.setSugar(rs.getDouble(10));
				f.setNatrium(rs.getDouble(11));
				f.setChole(rs.getDouble(12));
				f.setFattyacid(rs.getDouble(13));
				f.setTransfat(rs.getDouble(14));
				f.setMaker(rs.getString(15));
				foods.add(f);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return foods;
	}

	public FoodVO selectOne(int code) { //한 ㅇ
		String sql = "SELECT * FROM food WHERE f_code=?";

		FoodVO f = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, code);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				f = new FoodVO();
				f.setImg(rs.getString(1));
				f.setName(rs.getString(2));
				f.setMaterial(rs.getString(3));
				f.setCode(rs.getInt(4));
				f.setSupportpereat(rs.getDouble(5));
				f.setCalory(rs.getDouble(6));
				f.setCarbo(rs.getDouble(7));
				f.setProtein(rs.getDouble(8));
				f.setFat(rs.getDouble(9));
				f.setSugar(rs.getDouble(10));
				f.setNatrium(rs.getDouble(11));
				f.setChole(rs.getDouble(12));
				f.setFattyacid(rs.getDouble(13));
				f.setTransfat(rs.getDouble(14));
				f.setMaker(rs.getString(15));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return f;
	}

	public int delete(int code) {
		String sql = "DELETE FROM food WHERE f_code=?;";

		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, code);
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
}
