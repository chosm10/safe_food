package com.ssafy.dao;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.junit.BeforeClass;
import org.junit.Test;


public class MemberDaoTest {
	private static MemberDao dao;
	
	@BeforeClass
	public static void before() {
		dao = MemberDao.getInstance();
	}
	
//	@Test
//	public void insert() {
//		int beforeCnt = dao.selectAll().size();
//		MemberVO member = new MemberVO("chosm10", "조조조", "1234", "광주광역시", "1234-1234-1234");
//		dao.insertMember(member);
//		int afterCnt = dao.selectAll().size();
//		assertThat(afterCnt - beforeCnt, is(1));
//	}
	
//	@Test
//	public void update() {
//		int beforeCnt = dao.selectAll().size();
//		MemberVO member = new MemberVO("chosm10", "조조", "123", "광주광역시", "1234-1234-1234");
//		dao.updateMember(member);
//		int afterCnt = dao.selectAll().size();
//		assertThat(afterCnt - beforeCnt, is(0));
//	}
	
//	@Test
//	public void delete() {
//		int beforeCnt = dao.selectAll().size();
//		dao.deleteMember("chosm10");
//		int afterCnt = dao.selectAll().size();
//		assertThat(afterCnt - beforeCnt, is(-1));
//	}
}
