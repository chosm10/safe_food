package com.ssafy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.vo.FoodAllergyVO;


public class FoodAllergyDao {
	private static FoodAllergyDao instance = null;
	private Connection conn;

	private FoodAllergyDao() {
		// 커넥션 연결
		// 1. Driver 적재
		// 2. Connection 획득
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/safe_food?characterEncoding=UTF-8&serverTimezone=UTC","root","1234");
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static FoodAllergyDao getInstance() {
		if (instance == null)
			instance = new FoodAllergyDao();
		return instance;
	}

	public int insertFoodAllergy(FoodAllergyVO foodAlg) {
		String sql = "INSERT INTO food_allergy(allergy_alg_id, food_f_code) VALUES(?,?)";
		PreparedStatement pstmt = null;
		int result = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, foodAlg.getAllergyAlgId());
			pstmt.setInt(2, foodAlg.getFoodFCode());
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public int deleteMemberAllergy(int fCode) {
		String sql = "DELETE FROM food_allergy WHERE member_member_id = ?";
		PreparedStatement pstmt = null;
		int result = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, fCode);
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public List<FoodAllergyVO> selectOne(int fCode) {
		String sql = "SELECT * FROM food_allergy WHERE food_f_code = ?";
		PreparedStatement pstmt = null;
		List<FoodAllergyVO> foodAlg = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			foodAlg = new ArrayList<>();
			pstmt.setInt(1, fCode);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				FoodAllergyVO f= new FoodAllergyVO();
				f.setAllergyAlgId(rs.getInt(1));
				f.setFoodFCode(rs.getInt(2));
				foodAlg.add(f);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if(rs != null)
					rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return foodAlg;
	}
	
	public List<FoodAllergyVO> selectAll() {
		String sql = "SELECT * FROM food_allergy";
		PreparedStatement pstmt = null;
		FoodAllergyVO foodAlg = null;
		ResultSet rs = null;
		List<FoodAllergyVO> foodAlgList = new ArrayList<>();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				foodAlg = new FoodAllergyVO();
				foodAlg.setAllergyAlgId(rs.getInt(1));
				foodAlg.setFoodFCode(rs.getInt(2));
				foodAlgList.add(foodAlg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if(rs != null)
					rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return foodAlgList;
	}
}
